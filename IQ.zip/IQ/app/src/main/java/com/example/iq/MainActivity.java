package com.example.iq;

//import static com.google.android.material.internal.ContextUtils.getActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    EditText name;
    Button link;
    public static final String Name = "com.example.iq.extra.NAME";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        link = findViewById(R.id.link);
//        link.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String url = "https://www.codewithharry.com/";
//                Toast.makeText(MainActivity.this, url, Toast.LENGTH_SHORT).show();
//                Uri webpage = Uri.parse(url);
//                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
//                if (intent.resolveActivity(getPackageManager()) != null) {
//                    startActivity(intent);
//                }
//            }
//        });
    }


    public void TF(View v)
    {
        name = findViewById(R.id.name);
        String nameText = name.getText().toString();
        Toast.makeText(this, "All the best "+nameText, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        intent.putExtra(Name, nameText);
        startActivity(intent);
    }

    public void MCQS(View v)
    {
        name = findViewById(R.id.name);
        String nameText = name.getText().toString();
        Toast.makeText(this, "All the best "+nameText, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, MainActivity4.class);
        intent.putExtra(Name, nameText);
        startActivity(intent);
    }

    public void website(View v)
    {
        link = findViewById(R.id.link);
        String url = "https://www.codewithharry.com/";
        Toast.makeText(MainActivity.this, url, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);

    }
}