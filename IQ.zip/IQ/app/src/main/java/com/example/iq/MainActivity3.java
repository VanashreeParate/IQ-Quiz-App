package com.example.iq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    TextView res, thank;
    Button homepage, share;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent = getIntent();
        int score =intent.getIntExtra("Score", 0);
        int total = intent.getIntExtra("Total", 0);
        res = findViewById(R.id.result);
        res.setText(score+"/"+total);
        thank = findViewById(R.id.thank);
//        Intent intent_name = getIntent();
//        String name = intent_name.getStringExtra(MainActivity2.Name);
        String name = intent.getStringExtra(MainActivity2.Name);
        thank.setText("Thank you "+name+" for trying this quiz. Hope you visit us soon.");
        homepage = findViewById(R.id.homepage);
        homepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_home = new Intent(MainActivity3.this, MainActivity.class);
                startActivity(intent_home);
            }
        });
        share = findViewById(R.id.share);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_SUBJECT, "IQ Quiz Score");
                intent.putExtra(Intent.EXTRA_TEXT, "My Marks are "+score+"/"+total+" in True/False quiz game");
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
    }
}