package com.example.iq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    TextView qno, q;
    Button t, f;
    private String ques[] = {"Does South Africa has 1 capital?",
                             "An octopus has three hearts?",
                             "Is total length of Great Wall of China equal to half the length of equator?",
                             "Human skin regenerates every week?",
                             " French fries originated from Belgium?",
                             "Polo takes up the largest amount of space in terms of land area?"};
    private boolean ans[] = {false, true, true, false, true, true};
    private int index=0;
    private int score=0;
//    public static final String Score = "com.example.iq.extra.SCORE";
//    public static String Total = "com.example.iq.extra.TOTAL";
    public static final int Score = 0;
    public static final int Total = 0;
    public static final String Name = "com.examole.iq.extra.NAME";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        qno = findViewById(R.id.qno);
        q = findViewById(R.id.q);
        t = findViewById(R.id.t);
        f = findViewById(R.id.f);
        Intent intent = getIntent();
        String name = intent.getStringExtra(MainActivity.Name);

        qno.setText("Q"+(index+1));
        q.setText(ques[index]);

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index<ques.length)
                {
                    if(ans[index]==true)
                    {
                        score++;
//                        t.setBackgroundColor(Color.GREEN);
                        Toast.makeText(MainActivity2.this, "Correct", Toast.LENGTH_SHORT).show();

                    }
                    else
                    {
                        Toast.makeText(MainActivity2.this, "Wrong", Toast.LENGTH_SHORT).show();
                    }
                    index++;
                    if(index<ques.length)
                    {
                        qno.setText("Q"+(index+1));
                        q.setText(ques[index]);
//                        t.setBackgroundColor(android.R.drawable.btn_default);
                    }
                    else
                    {
//                        Toast.makeText(MainActivity2.this, "Score : "+score+"/"+ques.length, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                        intent.putExtra("Score", score);
                        intent.putExtra("Total", ques.length);
                        intent.putExtra(Name, name);
                        startActivity(intent);
                    }
                }
            }
        });
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index<ques.length) {
                    if (ans[index] == false) {
                        score++;
                        Toast.makeText(MainActivity2.this, "Correct", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(MainActivity2.this, "Wrong", Toast.LENGTH_SHORT).show();
                    }
                    index++;
                    if (index < ques.length) {
                        qno.setText("Q" + (index+1));
                        q.setText(ques[index]);
                    } else {
                        Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                        intent.putExtra("Score", score);
                        intent.putExtra("Total", ques.length);
                        intent.putExtra(Name, name);
                        startActivity(intent);
                    }
                }
            }
        });
    }
}