package com.example.iq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity5 extends AppCompatActivity {
    TextView res, thanks;
    Button share;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        Intent intent = getIntent();
        int score = intent.getIntExtra("Score", 0);
        int total = intent.getIntExtra("Total", 0);
        String name = intent.getStringExtra(MainActivity4.Name);
        res = findViewById(R.id.res);
        res.setText(score+"/"+total);
        thanks = findViewById(R.id.thanks);
        thanks.setText("Thank you "+name+"! Come prepared next time");
        share = findViewById(R.id.share_mcq);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_SUBJECT, "IQ Quiz Score");
                intent.putExtra(Intent.EXTRA_TEXT, "My Marks are "+score+"/"+total+" in MCQs quiz game");
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });

    }

    public void home(View v)
    {
        Intent intent_home = new Intent(MainActivity5.this, MainActivity.class);
        startActivity(intent_home);
    }
}