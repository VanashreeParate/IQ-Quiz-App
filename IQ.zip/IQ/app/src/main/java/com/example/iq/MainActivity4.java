package com.example.iq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {
    String ques[] = {"Which one is not the capital of South Africa?",
                     "Cheesecake comes from which country?",
                     "The metal whose salts are sensitive to light is?",
                     "Tsunamis are not caused by?",
                     "Which one of the following is not a nuclear power centre?",
                     "Guwahati High Court is the judicature of?"};
    int ans[] = {R.id.two, R.id.four, R.id.one, R.id.one, R.id.three, R.id.four};
    String option1[] = {"Pretoria", "Italy", "Silver", "Hurricanes", "Narora", "Assam"};
    String option2[] = {"Johannesburg", "Russia", "Zinc", "Earthquakes", "Kakrapara", "Nagaland"};
    String option3[] = {"Cape Town", "Portugal", "Copper", "Landslides", "Chamera", "Arunachal Pradesh"};
    String option4[] = {"Bloemfontein", "Greece", "Aluminium", "Volcanic eruptions", "Kota", "All of the above"};
    int index=0;
    int score=0;
    TextView question;
    RadioGroup radiogrp;
    RadioButton radiobutton, one, two, three, four;
    Button submit;
    public static final int Score = 0;
    public static final int Total = 0;
    public static final String Name = "com.examole.iq.extra.NAME";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        question = findViewById(R.id.question);
        question.setText("Q"+(index+1)+" "+ques[index]);
        radiogrp = findViewById(R.id.radioGroup);
        submit = findViewById(R.id.submit);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        one.setText(option1[index]);
        two.setText(option2[index]);
        three.setText(option3[index]);
        four.setText(option4[index]);
        Intent intent = getIntent();
        String name = intent.getStringExtra(MainActivity.Name);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index<ques.length)
                {
                    int id = radiogrp.getCheckedRadioButtonId();
                    if (id == ans[index])
                    {
                        score++;
                        Toast.makeText(MainActivity4.this, "Correct", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(MainActivity4.this, "Wrong", Toast.LENGTH_SHORT).show();
                    }
                    index++;
                    if (index < ques.length)
                    {
                        question.setText("Q" + (index + 1) + " " + ques[index]);
                        one.setText(option1[index]);
                        two.setText(option2[index]);
                        three.setText(option3[index]);
                        four.setText(option4[index]);
                        radiogrp.clearCheck();
                    }
                    else
                    {
                        Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                        intent.putExtra("Score", score);
                        intent.putExtra("Total", ques.length);
                        intent.putExtra(Name, name);
                        startActivity(intent);
                    }
                }
            }
        });
    }
}